class Person {
    firstName;
    lastName;
    color;
    dateOfBirth;
    constructor({ firstName,
        lastName,
        color,
        dateOfBirth }) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.color = color;
        this.dateOfBirth = dateOfBirth;

    }
}

gerard = new Person({ firstName: 'Gerard', lastName: 'Butler', color: 'Green', dateOfBirth: '1999-03-31' });
mike = new Person({ firstName: 'Mike', lastName: 'Daniels', color: 'Green', dateOfBirth: '1999-03-31' });
dan = new Person({ firstName: 'Dan', lastName: 'Vam', color: 'Blue', dateOfBirth: '1999-09-31' });

const people = { gerard, mike, dan };

module.exports = people;
