ex = require('express');
app = ex();
app.use('/bb', ex.static('dir'));
ws = require('ws');
getDate = function () {
    return new Date().toLocaleDateString();
}
getTime = () => {
    return new Date().getHours() + ':' + new Date().getMinutes();
}
people = require('./people.js');
console.log(people)
const server = new ws.Server({ port: '8081' });
let convo = {
    'How are you': 'Great!  And you?',
    'what\'s your name': 'Abacus',
    'What\'s the meaning of life': 'to be as happy as can be',
    'What do you do every day to make yourself happy': 'I walk every hour and run for an hour',
    'What\'s the date': getDate,
    'the date': getDate,
    'date': getDate,
    'What time is it': getTime,
    'What time': getTime,
    'time': getTime,
    'what\'s your favorite color': 'blue'
}

Object.keys(convo).forEach((x, y) => {
    convo = { ...convo, [x.toString().toLowerCase()]: convo[x] };
});
server.on('connection', socket => {
    socket.on('message', message => {
        if (message[message.length - 1] === '?') {
            message = message.substring(0, message.length - 1);
        }

        let ans = convo[message];

        if (typeof (ans) == 'function') {
            ans = ans();
        }

        if (!ans) {
            ans = 'Do the best you can!';
        }
        socket.send(ans);
    });
    socket.send("I'm the best");

});

app.get('/a', (req, res) => {
    res.send('asdffdsa');
})
app.listen(8080);
